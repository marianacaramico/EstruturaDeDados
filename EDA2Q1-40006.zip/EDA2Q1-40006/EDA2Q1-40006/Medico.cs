﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA2Q1_40006
{
    class Medico
    {
        private string nome;
        private int crm;
        private int numConsultas;
        private float valorConsulta;

        public string Nome { get => nome; set => nome = value; }
        public int Crm { get => crm; set => crm = value; }
        public int NumConsultas { get => numConsultas; set => numConsultas = value; }
        public float ValorConsulta { get => valorConsulta; set => valorConsulta = value; }

        public Medico(string nome, int crm, float valorConsulta)
        {
            this.nome = nome;
            this.crm = crm;
            this.valorConsulta = valorConsulta;
        }

        public void Exibir()
        {
            Console.WriteLine("Nome: "+this.nome+"\nCRM: "+this.crm+"\nValor da Consulta: "+this.valorConsulta);
        }

        public float CalculaGanho(float valorConsulta, int numConsultas)
        {
            return valorConsulta * numConsultas;
        }

    }
}
