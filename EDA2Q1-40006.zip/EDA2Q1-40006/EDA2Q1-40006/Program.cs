﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA2Q1_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            Medico m1 = new Medico("José", 2526, 200);
            Medico m2 = new Medico("Maria", 12230, 300);
            m1.NumConsultas = 20;
            m2.NumConsultas = 40;
            m1.Exibir();
            Console.WriteLine("O ganho de "+m1.Nome+" no mês é de R$"+m1.CalculaGanho(m1.ValorConsulta,m1.NumConsultas)+"\n");
            m2.Exibir();
            Console.WriteLine("O ganho de "+m2.Nome+" no mês é de R$" +m2.CalculaGanho(m2.ValorConsulta,m2.NumConsultas));

            Console.ReadKey();
        }
    }
}
