﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA2Q2_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numeros = new int[2];
            for (int i = 0; i < 2; i++)
            {
                while (numeros[i] < 2 || numeros[i] > 18)
                {
                    Console.WriteLine("Digite o valor do " + (i + 1) + "º número:");
                    numeros[i] = int.Parse(Console.ReadLine());
                }
            }
            DivPar n1 = new DivPar(numeros[0]);
            DivPar n2 = new DivPar(numeros[1]);

            n1.Exibir(numeros[0]);
            n2.Exibir(numeros[1]);
            
            Console.WriteLine("Exibindo a soma dos divisores pares de " + numeros[0] + ": " + n1.Somar(numeros[0]));
            Console.WriteLine("Exibindo a soma dos divisores pares de " + numeros[1] + ": " + n2.Somar(numeros[1]));

            Console.ReadKey();
            

        }
    }
}
