﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA2Q2_40006
{
    class DivPar
    {
        private int num;
        private int count;

        public DivPar(int num)
        {
            this.Num = num;
        }

        public int Num { get => num; set => num = value; }
        public int Count { get => count; set => count = value; }

        public void Exibir(int num)
        {
            Console.WriteLine("Exibindo os divisores de " + num);
            for (int i = 1; i <= num; i++) {
                if (this.Num % 2 == 0)
                {                 
                    Console.WriteLine(i);
                }
            }
        }

        public int Somar(int num)
        {
            for (int i = 1; i <= num; i++)
            {
                if (this.Num % 2 == 0)
                {
                    this.Count = Count + i;
                }
            }            
            return this.Count;
        }

    }
}
