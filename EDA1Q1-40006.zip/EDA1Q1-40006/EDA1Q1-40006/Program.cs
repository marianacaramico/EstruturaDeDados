﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA1Q1_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Bienal do Livro 2018 que dura 3 dias
             * Crie um programa no qual o usuário informa seu nome,
             * a quantidade de dias que irá ao evento,
             * o custo do ingresso por dia (considerando que o valor é o mesmo para cada dia).
             * Se o usuário for a 1 dia de evento, exiba 'Seu bolso está tranquilo';
             * Se o usuário for a 2 dias de evento, exiba 'Seu bolso está apertado';
             * Se o usuário for a 3 dias de evento, exiba 'Assim você ficará pobre!'.
             * Ao final de tudo, exiba o quanto o usuário gastará na compra dos ingressos.
            */
            Console.WriteLine("Informe seu nome:");
            string nome = Console.ReadLine();
            Console.WriteLine("Irá a quantos dias de evento? 1, 2 ou 3?");
            int dias = int.Parse(Console.ReadLine());
            Console.WriteLine("Qual o valor do ingresso diário?");
            double valor = double.Parse(Console.ReadLine());
            double gasto = dias * valor;
            switch (dias)
            {
                case 1: Console.WriteLine("Seu bolso está tranquilo.");
                    break;
                case 2: Console.WriteLine("Seu bolso está apertado.");
                    break;
                case 3: Console.WriteLine("Assim você ficará pobre!");
                    break;
            }
            Console.WriteLine("Indo a "+dias+" dias do evento, você gastará R$" + gasto + ", "+nome+".");
            Console.ReadKey();
        }
    }
}
