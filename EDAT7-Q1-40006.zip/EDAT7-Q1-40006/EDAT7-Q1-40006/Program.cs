﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAT7_Q1_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            ListaLigadaOrdenadaCrescente lista = new ListaLigadaOrdenadaCrescente();
            lista.InsereNode(30);
            lista.InsereNode(50);
            lista.InsereNode(10);
            lista.Imprime();
            Node x = lista.BuscaNode(30);
            if (x == null) Console.WriteLine("Não encontrado.");
            else Console.WriteLine(x.Info);
            lista.RemoveNode(10);
            lista.Imprime();

            Console.ReadKey();

        }
    }
}
