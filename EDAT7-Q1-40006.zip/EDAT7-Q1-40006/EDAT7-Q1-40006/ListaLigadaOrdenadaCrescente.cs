﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAT7_Q1_40006
{
    class ListaLigadaOrdenadaCrescente : ListaLigada
    {
        public override void InsereNode(int valor)
        {
            Node novo = new Node(valor);
            bool inseriu = false;
            Node atual = Head.Next;
            Node anterior = Head;
            while (atual != null && !inseriu)
            {
                if (valor < atual.Info)
                {
                    novo.Next = atual;
                    anterior.Next = novo;
                    inseriu = true;
                }
                else
                {
                    anterior = anterior.Next;
                    atual = atual.Next;
                }
            }
            if (!inseriu) anterior.Next = novo;
            
        }

        public override Node BuscaNode(int valor)
        {
            Node atual = Head.Next;
            while (atual != null && atual.Info <= valor)
            {
                if (atual.Info == valor) return atual;
                atual = atual.Next;
            }
            return null;
        }

    }
}
