﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAT7_Q1_40006
{
    class ListaLigada
    {
        private Node head;

        internal Node Head { get => head; set => head = value; }

        public ListaLigada()
        {
            this.Head = new Node(0);
        }

        public virtual void InsereNode(int valor)
        {
            Node novo = new Node(valor);
            novo.Next = Head.Next;
            Head.Next = novo;
        }

        public void Imprime()
        {
            Node atual = Head.Next;
            while (atual != null)
            {
                Console.WriteLine(atual.Info);
                atual = atual.Next;
            }
        }

        public virtual Node BuscaNode(int valor)
        {
            Node atual = Head.Next;
            while (atual != null)
            {
                if (atual.Info == valor) return atual;
                atual = atual.Next;
            }
            return null;
        }

        public bool RemoveNode(int valor)
        {
            Node anterior = Head;
            Node atual = Head.Next;
            while (atual != null)
            {
                if (atual.Info == valor)
                {
                    anterior.Next = atual.Next;
                    return true;
                }
                anterior = atual;
                atual = atual.Next;
            }
            return false;
        }

        public int Tamanho()
        {
            Node atual = Head.Next;
            int tamanho = 0;
            while (atual != null)
            {
                tamanho++;
                atual = atual.Next;
            }
            return tamanho;
        }
    }
}
