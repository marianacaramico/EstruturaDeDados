﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA4_40006
{
    class Vendedor : Funcionario
    {
        private int vendas;
        private double comissao;

        public int Vendas { get => vendas; set => vendas = value; }
        public double Comissao { get => comissao; set => comissao = value; }

        public Vendedor(int vendas, double comissao, string nome, string cpf) : base(nome, cpf)
        {
            this.Vendas = vendas;
            this.Comissao = comissao;
        }
        
        public override double CalcSalario()
        {
            return Vendas*Comissao;
        }

        public override string ToString()
        {
            return "Nome do vendedor: "+this.Nome+". CPF: "+this.Cpf+". Número de vendas: "+this.Vendas+". " +
                "Comissao: "+this.Comissao+". Salário: "+CalcSalario();
        }
    }
}
