﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA4_40006
{
    class Empresa
    {
        private ListaObj lista;

        public Empresa(int tamanho)
        {
            lista = new ListaObj(tamanho);
        }

        public void AdicionaFunc(Funcionario f)
        {
            lista.Adicionar(f);
        }

        public void ExibeFunc()
        {
            for(int i=0; i<lista.NroElem; i++)
            {
                lista.GetElemento(i).ToString();
            }
        }

        public double ExibeTotalSalario()
        {
            double salarios = 0;            
            for(int i=0; i<lista.NroElem; i++)
            {
                Funcionario f = (Funcionario)lista.GetElemento(i);
                salarios += f.CalcSalario();
            } return salarios;
        }

        public Funcionario BuscaFunc(string cpf)
        {
            for(int i=0; i<lista.NroElem; i++)
            {
                Funcionario f = (Funcionario)lista.GetElemento(i);
                if (f.Cpf == cpf)
                {
                    return f;
                }
            }
            return null;
        }

    }
}
