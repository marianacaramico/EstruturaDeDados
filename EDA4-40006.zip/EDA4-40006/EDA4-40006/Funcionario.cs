﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA4_40006
{
    abstract class Funcionario
    {
        private string nome;
        private string cpf;

        public string Nome { get => nome; set => nome = value; }
        public string Cpf { get => cpf; set => cpf = value; }

        public Funcionario(string nome, string cpf)
        {
            this.nome = nome;
            this.cpf = cpf;
        }

        public override string ToString()
        {
            return "Nome do funcionário: "+this.nome+". CPF: "+this.cpf+".";
        }

        public abstract double CalcSalario();

    }
}
