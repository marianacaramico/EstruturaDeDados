﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA4_40006
{
    class Horista : Funcionario
    {
        private int qtdHora;
        private double valorHora;       

        public int QtdHora { get => qtdHora; set => qtdHora = value; }
        public double ValorHora { get => valorHora; set => valorHora = value; }

        public Horista(int qtdHora, double valorHora, string nome, string cpf) : base(nome, cpf)
        {
            this.qtdHora = qtdHora;
            this.valorHora = valorHora;
        }

        public override double CalcSalario()
        {
            return this.qtdHora * this.valorHora;
        }

        public override string ToString()
        {
            return "Nome do horista: "+this.Nome+". CPF: "+this.Cpf+". Quantidade de horas trabalhadas: "+this.qtdHora+". " +
                "Valor ganho por hora trabalhada: "+this.valorHora+". Salário: "+CalcSalario();
        }
    }
}
