﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA4_40006
{
    class Engenheiro : Funcionario
    {
        private double salario;
        
        public double Salario { get => salario; set => salario = value; }

        public Engenheiro(double salario, string nome, string cpf) : base(nome, cpf)
        {
            this.salario = salario;
        }

        public override double CalcSalario()
        {
            return this.salario;
        }

        public override string ToString()
        {
            return "Nome do engenheiro: "+this.Nome+". CPF: "+this.Cpf+". Salário: "+CalcSalario()+".";
        }
    }
}
