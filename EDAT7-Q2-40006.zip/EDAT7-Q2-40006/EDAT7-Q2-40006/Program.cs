﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAT7_Q2_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            ListaLigada lista = new ListaLigada();
            lista.InsereNode(11);
            lista.InsereNode(37);
            lista.InsereNode(32);
            lista.InsereNode(35);
            lista.InsereNode(39);
            lista.InsereNode(42);
            lista.InsereNode(43);
            lista.Imprime();
            Console.WriteLine("------");
            lista.InsereAntesPar(3);
            lista.Imprime();
            Console.WriteLine("------");
            lista.RemoveImpares();
            lista.Imprime();

            Console.ReadKey();
        }
    }
}
