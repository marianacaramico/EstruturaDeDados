﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAT7_Q2_40006
{
    class ListaLigada
    {
        private Node head;

        internal Node Head { get => head; set => head = value; }

        public ListaLigada()
        {
            this.Head = new Node(0);
        }

        public void InsereNode(int valor)
        {
            Node novo = new Node(valor);
            novo.Next = Head.Next;
            Head.Next = novo;
        }

        public void Imprime()
        {
            Node atual = Head.Next;
            while (atual != null)
            {
                Console.WriteLine(atual.Info);
                atual = atual.Next;
            }
        }

        public Node BuscaNode(int valor)
        {
            Node atual = Head.Next;
            while (atual != null)
            {
                if (atual.Info == valor) return atual;
                atual = atual.Next;
            }
            return null;
        }

        public bool RemoveNode(int valor)
        {
            Node anterior = Head;
            Node atual = Head.Next;
            while (atual != null)
            {
                if (atual.Info == valor)
                {
                    anterior.Next = atual.Next;
                    return true;
                }
                anterior = atual;
                atual = atual.Next;
            }
            return false;
        }

        public int Tamanho()
        {
            Node atual = Head.Next;
            int tamanho = 0;
            while (atual != null)
            {
                tamanho++;
                atual = atual.Next;
            }
            return tamanho;
        }

        public void InsereAntesPar(int valor)
        {
            Node novo = new Node(valor);
            bool inseriu = false;
            Node atual = Head.Next;
            Node anterior = Head;
            while (atual != null && !inseriu)
            {
                if (atual.Info % 2 == 0)
                {
                    novo.Next = atual;
                    anterior.Next = novo;
                    inseriu = true;
                }
                else
                {
                    anterior = anterior.Next;
                    atual = atual.Next;
                }
            }
            if (!inseriu) anterior.Next = novo;

        }

        public void RemoveImpares()
        {
            Node anterior = Head;
            Node atual = Head.Next;
            while(atual != null)
            {
                if (atual.Info % 2 != 0)
                {
                    anterior.Next = atual.Next;
                    atual = atual.Next;
                }
                else
                {
                    anterior = atual;
                    atual = atual.Next;
                }
            }
            


        }

    }
}
