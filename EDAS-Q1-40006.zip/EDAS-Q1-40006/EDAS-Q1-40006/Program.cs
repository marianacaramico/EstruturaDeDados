﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAS_Q1_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            ListaLigada lista = new ListaLigada();
            lista.InsereNode(10);
            lista.InsereNode(13);
            lista.InsereNode(15);
            lista.InsereNode(25);
            lista.InsereNode(11);
            lista.Imprime();
            Console.WriteLine("-------");
            lista.InsereXantesY(8, 13);
            lista.Imprime();
            Console.WriteLine("-------");
            lista.RemoveTerceiroQuinto();
            lista.Imprime();
            Console.WriteLine("-------");

            Console.ReadKey();

        }
    }
}
