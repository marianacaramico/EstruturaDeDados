﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAS_Q1_40006
{
    class ListaLigada
    {
        private Node head;

        internal Node Head { get => head; set => head = value; }

        public ListaLigada()
        {
            this.Head = new Node(0);
        }

        public void InsereNode(int valor)
        {
            Node novo = new Node(valor);
            novo.Next = Head.Next;
            Head.Next = novo;
        }

        public void Imprime()
        {
            Node atual = Head.Next;
            while (atual != null)
            {
                Console.WriteLine(atual.Info);
                atual = atual.Next;
            }
        }

        public Node BuscaNode(int valor)
        {
            Node atual = Head.Next;
            while (atual != null)
            {
                if (atual.Info == valor) return atual;
                atual = atual.Next;
            }
            return null;
        }

        public bool RemoveNode(int valor)
        {
            Node anterior = Head;
            Node atual = Head.Next;
            while (atual != null)
            {
                if (atual.Info == valor)
                {
                    anterior.Next = atual.Next;
                    return true;
                }
                anterior = atual;
                atual = atual.Next;
            }
            return false;
        }

        public int Tamanho()
        {
            Node atual = Head.Next;
            int tamanho = 0;
            while (atual != null)
            {
                tamanho++;
                atual = atual.Next;
            }
            return tamanho;
        }

        public void InsereXantesY(int x, int y)
        {
            Node novo = new Node(x);
            bool inseriu = false;
            Node atual = Head.Next;
            Node anterior = Head;
            while (atual != null && !inseriu)
            {
                if (atual.Info == y)
                {
                    novo.Next = atual;
                    anterior.Next = novo;
                    inseriu = true;
                }
                else
                {
                    anterior = anterior.Next;
                    atual = atual.Next;
                }
            }
            if (!inseriu) anterior.Next = novo;            
        }

        public void RemoveTerceiroQuinto()
        {
            if (Head.Next.Next != null || Head.Next.Next.Next.Next != null)
            {
                Node anterior = Head;
                Node atual = Head.Next;
                Node terceiro = Head.Next.Next.Next;
                Node quinto = Head.Next.Next.Next.Next.Next;
                while (atual != null)
                {
                    if (atual == terceiro || atual == quinto)
                    {
                        anterior.Next = atual.Next;
                        atual = atual.Next;
                    }
                    else
                    {
                        anterior = atual;
                        atual = atual.Next;
                    }
                }
            }
        }
    }
}
