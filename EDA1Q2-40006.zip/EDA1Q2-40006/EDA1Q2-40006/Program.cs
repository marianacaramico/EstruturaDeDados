﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA1Q2_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            while (n < 2 || n > 25)
            {
                Console.WriteLine("Informe o número de atletas:");
                n = int.Parse(Console.ReadLine());
            }
            int[] vetor = new int[n];
            int soma = 0;
            for (int i = 0; i < vetor.Length; i++)
            {
                Console.WriteLine("Informe a idade do atleta "+(i+1)+":");
                vetor[i] = int.Parse(Console.ReadLine());
                soma = soma + vetor[i];
            }
            double media = soma / vetor.Length;
            int count = 0;
            int[] acimaDaMedia = new int[vetor.Length];
            for(int j = 0; j < vetor.Length; j++)
            {
                if (vetor[j] > media)
                {
                    acimaDaMedia[j] = vetor[j];
                    count++;
                }
            }
            Console.WriteLine("Quantidade de idades acima da média: " + count);
            for (int k = 0; k < acimaDaMedia.Length; k++)
            {
                if (acimaDaMedia[k] > 0)
                {
                    Console.WriteLine("Idade acima da média: " + acimaDaMedia[k]);
                }
            }
            Console.ReadKey();
        }
    }
}
