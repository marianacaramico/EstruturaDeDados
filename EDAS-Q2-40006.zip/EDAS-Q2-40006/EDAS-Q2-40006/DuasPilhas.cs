﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAS_Q2_40006
{
    class DuasPilhas
    {
        private int[] vetor;
        private int topo1;
        private int topo2;

        public DuasPilhas(int topo1, int topo2, int n)
        {
            this.topo1 = topo1;
            this.topo2 = topo2;
            this.Vetor = new int[n];
            this.Vetor[0] = this.topo1;
            this.Vetor[n - 1] = this.topo2;
        }

        public int[] Vetor { get => vetor; set => vetor = value; }

        public bool isEmpty(int p)
        {
            if (p == 1)
            {
                if (vetor[1] == 0) return true;
                else return false;
            }
            else {
                if (vetor[vetor.Length - 2] == 0) return true;
                else return false;
            }

        }

        public bool isFull(int p)
        {
            if (p == 1)
            {
                for (int i = 0; i < Vetor.Length; i++)
                {
                    if (Vetor[i] == 0)
                    {
                        return false;
                    }
                }
                return true;
            }
            else
            {
                for (int j = Vetor.Length - 1; j > 0; j--)
                {
                    if (Vetor[j] == 0)
                    {                        
                        return false;
                    }
                }
                return true;
            }

        }

        public void Push(int v, int p)
        {
            if (!isFull(p))
            {
                if (p == 1)
                {
                    for (int i = 1; i < Vetor.Length; i++)
                    {
                        if (Vetor[i] != 0)
                        {
                            Vetor[i] = v;
                            return;
                        }
                    }
                }
                if (p == 2)
                {
                    for (int j = Vetor.Length - 2; j > 0; j--)
                    {
                        if (Vetor[j] != 0)
                        {
                            Vetor[j] = v;
                            return;
                        }
                    }
                }
            }
        }

        public int Pop(int p)
        {
            int retorno = 0;
            if (!isEmpty(p))
            {
                if (p == 1)
                {
                    for (int i = 0; i < Vetor.Length; i++)
                    {
                        if (Vetor[i] == 0)
                        {
                            retorno = vetor[i - 1];
                            vetor[i - 1] = 0;
                            return retorno;
                        }
                    }
                }
                else
                {
                    for (int j = Vetor.Length - 1; j > 0; j--)
                    {
                        if (Vetor[j] == 0)
                        {
                            retorno = vetor[j + 1];
                            vetor[j + 1] = 0;
                            return retorno;
                        }
                    }
                }
            }
            return 0;
        }




    }
}
