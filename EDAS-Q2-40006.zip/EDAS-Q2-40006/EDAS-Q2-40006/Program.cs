﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDAS_Q2_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            DuasPilhas pilhas = new DuasPilhas(1, 5, 10);
            pilhas.Push(2, 1);
            pilhas.Push(3, 2);
            pilhas.Push(4, 1);
            pilhas.Push(8, 2);
            Console.WriteLine("----");

            Console.ReadKey();


        }
    }
}
