﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA3_40006
{
    class Program
    {
        static void Main(string[] args)
        {
            ListaEstatica lista = new ListaEstatica(5);
            lista.AdicionarInicio(4);
            lista.AdicionarInicio(2);
            lista.AdicionarInicio(1);
            lista.AdicionarNoIndice(3, 2);
            lista.AdicionarNoIndice(5, 4);
            lista.SubstituirElemento(2, 10);

            Console.ReadKey();
        }
    }
}
