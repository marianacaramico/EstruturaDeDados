﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA3_40006
{
    class ListaEstatica
    {
        private int[] vetor;
        private int nroElem;

        public int NroElem { get => nroElem; set => nroElem = value; }

        public ListaEstatica(int tam)
        {
            vetor = new int[tam];
            nroElem = 0;
        }

        public int Adicionar(int elem)
        {
            if (this.nroElem < vetor.Length)
            {
                vetor[nroElem] = elem;
                nroElem++;
                return 0;
            }
            else
            {
                return -1;
            }
        }

        public void Exibir()
        {
            for (int i = 0; i < this.nroElem; i++)
            {
                Console.WriteLine(vetor[i]);
            }
        }

        public int Buscar(int elemento)
        {
            for (int i = 0; i < this.nroElem; i++)
            {
                if (vetor[i] == elemento) return i;
            }
            return -1;
        }

        public int RemoverPeloIndice(int indice)
        {
            if (indice >= 0 && indice < nroElem)
            {
                for (int i = indice; i < this.nroElem - 1; i++)
                {
                    vetor[i] = vetor[i + 1];
                }
                nroElem--;
                vetor[nroElem] = 0;
                return 0;
            }
            return -1;
        }

        public int RemoverElemento(int elementoRemovido)
        {
            return this.RemoverPeloIndice(this.Buscar(elementoRemovido));
        }

        public int AdicionarInicio(int valor)
        {
            if (valor > 0)
            {
                for (int i = this.nroElem; i > 0; i--)
                {
                    vetor[i] = vetor[i - 1];
                }
                nroElem++;
                vetor[0] = valor;
                return 0;
            }
            return -1;
        }

        public int AdicionarNoIndice(int val, int ind)
        {
            if (ind > nroElem || vetor[vetor.Length-1]!=0) return -1;
            for (int i = this.nroElem; i > 0; i--)
            {
                vetor[i] = vetor[i-1];
                if (i == ind)
                {
                    vetor[i] = val;
                    nroElem++;
                    return 0;
                }
            }
            return 0;
        }

        public int SubstituirElemento(int value, int valueSubs)
        {
            for(int i=0; i < vetor.Length; i++)
            {
                if (vetor[i] == value) {
                    vetor[i] = valueSubs;
                    return 0;
                }
            }
            return -1;
        }
    }
}
